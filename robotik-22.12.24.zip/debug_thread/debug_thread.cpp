#include "debug_thread.h"
#include "../options.h"

#include "../dependencies/definitions/other.h"

#include <iostream>
#include <vector>
#include <string>

#include "imgui/imgui.h"
#include "imgui/imgui_impl_glfw.h"
#include "imgui/imgui_impl_opengl3.h"


void get_Errors(int line, const char* file) {
    GLenum error = glGetError();
    std::cout << line << "; " << file << "; ";
    if (error != GL_NO_ERROR) {
        std::cout << error << std::endl;
    }
    else {
        std::cout << "no error." << std::endl;
    }
}

#ifdef ENABLE_DEBUG

float cp_x;
float cp_y;
int offset_cpx;
int offset_cpy;
int w_posx;
int w_posy;
int buttonEvent;

int width = 1000;
int height = 500;

std::vector<float> fps_stats = {0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5};
std::vector<const char*> logs = {"started."};


GLFWwindow* imGuiwindow;
bool kill_debug_thread = false;

bool lock_data = false;


int* LOGIC_THREAD_STATUS = nullptr;
int* GENERATION_THREAD_STATUS = nullptr;



void cursor_position_callback(GLFWwindow* window, double x, double y) {
    if (buttonEvent == 1) {
        offset_cpx = x - cp_x;
        offset_cpy = y - cp_y;
    }
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
        buttonEvent = 1;
        double x, y;
        glfwGetCursorPos(window, &x, &y);
        cp_x = floor(x);
        cp_y = floor(y);
    }
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE) {
        buttonEvent = 0;
        cp_x = 0;
        cp_y = 0;
    }
}


void DEBUG::push_fps(float fps) {
    while (lock_data) {};
    lock_data = true;
    fps_stats.push_back(fps);
    lock_data = false;
}
void DEBUG::log(const char* message) {
    while (lock_data) {};
    lock_data = true;
    logs.push_back(message);
    lock_data = false;
}



void DEBUG::init(int& _LOGIC_THREAD_STATUS, int& _GENERATION_THREAD_STATUS) {
    LOGIC_THREAD_STATUS = &_LOGIC_THREAD_STATUS;
    GENERATION_THREAD_STATUS = &_GENERATION_THREAD_STATUS;

}

void init_window() {
    glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);
    imGuiwindow = glfwCreateWindow(width, height, "Debug", NULL, NULL);

    glfwMakeContextCurrent(imGuiwindow);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = NULL;

    ImGui::StyleColorsDark();

    ImGui_ImplGlfw_InitForOpenGL(imGuiwindow, true);

    ImGui_ImplOpenGL3_Init("#version 330 core");

    glfwSetCursorPosCallback(imGuiwindow, cursor_position_callback);
    glfwSetMouseButtonCallback(imGuiwindow, mouse_button_callback);
}

void DEBUG::run() {
    log_console("DEBUG", "starting.");

    init_window();

    glfwMakeContextCurrent(imGuiwindow);


    ImGuiIO& io = ImGui::GetIO();


    while (!kill_debug_thread && !glfwWindowShouldClose(imGuiwindow)) {
        glfwPollEvents();

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();


        ImGui::Begin("Debug");

        ImGui::SetWindowFontScale(2.3f);

        ImGui::PushItemWidth(250);

        while (lock_data) {};
        lock_data = true;

        auto begin = fps_stats.begin() + std::max(0, (int)fps_stats.size() - 150);
        auto end = fps_stats.end();


        float min = *std::min_element(
            begin, end
        );
        float max = *std::max_element(
            begin, end
        );

        lock_data = false;
        
        ImGui::PlotLines(
            ("FPS: " + std::to_string(fps_stats.back())).c_str(),

            &fps_stats[std::max(0, (int)fps_stats.size() - 100)],
            std::min(100, (int)fps_stats.size()),

            0, nullptr, min, max
        );


        ImGui::Text(("Statuses:\nLogic: "
            + std::to_string(*LOGIC_THREAD_STATUS) +
            ";\nGeneration: " + std::to_string(*GENERATION_THREAD_STATUS)
            ).c_str()
        );


        int begin_off = std::max(0, (int)logs.size() - 10);
        /*
        const char* last_log = "";
        int repeat = 0;
        for (int i = 0; i < std::min(10, (int)logs.size()); i++) {
            if ((i + 1 < logs.size()) and (logs[i] == logs[i + 1])) {}
                //repeat++;
            else {
                ImGui::Text((
                    std::to_string(*logs[i]) +
                    " (x" + std::to_string(repeat) + ")"
                ).c_str());
                repeat = 0;
            }
        }*/

        ImGui::SetWindowPos(ImVec2(0, 0));
        ImGui::SetWindowSize(ImVec2((float)width, (float)height));
        ImGui::End();



        float display_w = ImGui::GetWindowSize().x;
        float display_h = ImGui::GetWindowSize().y;

        ImGui::Render();

        glViewport(0, 0, display_w, display_h);
        glClearColor(0.01f, 0.01f, 0.1f, 0.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        if (buttonEvent == 1) {
            glfwGetWindowPos(imGuiwindow, &w_posx, &w_posy);
            glfwSetWindowPos(imGuiwindow, w_posx + offset_cpx, w_posy + offset_cpy);
            offset_cpx = 0;
            offset_cpy = 0;
            cp_x += offset_cpx;
            cp_y += offset_cpy;
        }

        glfwSwapBuffers(imGuiwindow);


        if (fps_stats.size() > 100)
            fps_stats.erase(fps_stats.begin(), fps_stats.begin() + (fps_stats.size() - 100));

        std::this_thread::sleep_for(std::chrono::milliseconds(16));
	}
}

void DEBUG::exit(std::thread* thread) {
    log_console("DEBUG", "requested to exit.");

    glfwSetWindowShouldClose(imGuiwindow, true);
    kill_debug_thread = true;

    if (thread->joinable()) {
        thread->join();
    }

    glfwMakeContextCurrent(imGuiwindow);

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();

    ImGui::DestroyContext();

    glfwDestroyWindow(imGuiwindow);

    glfwTerminate();

    log_console("DEBUG", "exited.");
}

GLFWwindow* DEBUG::get_window() {
    return imGuiwindow;
}


#else

void DEBUG::push_fps(float fps) {};
void DEBUG::log(const char* message) {};

void DEBUG::init(int& _LOGIC_THREAD_STATUS, int& _GENERATION_THREAD_STATUS) {};
void DEBUG::run() {};
void DEBUG::exit(std::thread* thread) {};

GLFWwindow* DEBUG::get_window() {
    std::cout << "DEBUG::get_window() is a debug function. Enable debug to use it.";
    throw 0;
}

#endif