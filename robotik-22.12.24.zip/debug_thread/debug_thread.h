#pragma once

#include <thread>
#include <glad/glad.h>
#include <GLFW/glfw3.h>


#define checkErrors() get_Errors(__LINE__, __FILE__)

void get_Errors(int line, const char* file);

namespace DEBUG {
	void init(int& _LOGIC_THREAD_STATUS, int& _GENERATION_THREAD_STATUS);

	void run();

	void exit(std::thread* thread);

	void push_fps(float fps);

	void log(const char* message);

	GLFWwindow* get_window();
}
