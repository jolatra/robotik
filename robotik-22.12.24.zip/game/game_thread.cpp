#include "game_thread.h"

// glfw and glad already included in header

#include <glm/common.hpp>
#include <glm/geometric.hpp>

#include <iostream>
#include <vector>
#include <thread>

#include "singleheader/stb_image.h"

#include "../debug_thread/debug_thread.h"

#include "world_gen.h"

#include "definitions/object.h"
#include "definitions/other.h"


bool kill_logic_thread = false;
int* LOGIC_STATUS_VAR = nullptr;


bool kill_generation_thread = false;
int* GENERATION_STATUS_VAR = nullptr;


GLFWwindow* window;

World world;

Texture player_tex;


namespace LOGIC {
    void init(int& _LOGIC_STATUS_VAR, int& _GENERATION_STATUS_VAR, GLFWwindow* _window);

    void run();

    void exit(std::thread* thread);

    void get_data(std::vector<float>* vertices, std::vector<int>* indices);
    void get_player_scr_data(std::vector<float>* vertices, std::vector<int>* indices);

    unsigned int get_spritesheet_ID();

    Texture main_spritesheet;

    Player player;
}



// THREAD LOGIC
void LOGIC::init(int& _LOGIC_STATUS_VAR, int& _GENERATION_STATUS_VAR, GLFWwindow* _window) {
    LOGIC_STATUS_VAR = &_LOGIC_STATUS_VAR;
    GENERATION_STATUS_VAR = &_GENERATION_STATUS_VAR;

    LOGIC::main_spritesheet.init("assets/textures/main_spritesheet.png", "png", false);
    player_tex.init("assets/textures/player.png", "png", false);
    /*
    glTexSubImage2D(
        GL_TEXTURE_2D, 0, // Target and level
        16 * 3, 0, 16, 16, // Offset and size
        GL_RGBA, GL_UNSIGNED_BYTE, // Format and type
        stbi_load("assets/icon.png", nullptr, nullptr, 0, 4) // Pointer to the new pixel data
    );*/
    
    window = _window;
	
    GENERATION::init();

    LOGIC::player = Player(0, 0);
}

unsigned int LOGIC::get_spritesheet_ID() {
    return LOGIC::main_spritesheet.ID;
}

void LOGIC::run() {
    glfwMakeContextCurrent(window);

    *LOGIC_STATUS_VAR = 1;

    while (!kill_logic_thread) {

    }

    DEBUG::log("LOGIC exiting");
    *LOGIC_STATUS_VAR = 2;
}

void LOGIC::exit(std::thread* thread) {
    DEBUG::log("LOGIC requested to exit");
    kill_logic_thread = true;
    if (thread->joinable()) {
        thread->join();
    }
}



void LOGIC::get_data(std::vector<float>* vertices, std::vector<int>* indices) {
    for (Chunk cnk : world.chunks) {
        for (Block blk : cnk.content) {
            blk.get_data(*&vertices, *&indices);
        }
    }
}


void LOGIC::get_player_scr_data(std::vector<float>* vertices, std::vector<int>* indices) {
    LOGIC::player.get_data(&*vertices, &*indices);
}



Player::Player(float _x, float _y) {
    x = _x; y = _y;
    w = 1; // 32 = width of player texture
    h = 1; // 32 = height of player texture
}

void Player::get_data(std::vector<float>* vertices, std::vector<int>* indices) {
    for (float p : {
            x,          y,          3.0f, 3.0f,
            x + w,      y,          4.0f, 3.0f,
            x + w,      y + h,      4.0f, 4.0f,
            x,          y + h,      3.0f, 4.0f
    }) {
        vertices->push_back(p);
    }

    int offset = indices->size() / 6 * 4;
    for (int v : {0, 1, 3, 1, 2, 3}) {
        indices->push_back(v + offset);
    }
}

void Player::moveto(float _x, float _y) {
    x = _x;
    y = _y;
}
void Player::moveby(float _x, float _y) {
    x += _x;
    y += _y;
}




// GENERATION

void GENERATION::init() {
    // status var set by LOGIC::init
}

void GENERATION::run() {
    // EXECUTED BY GEN THREAD
    world = World("world1", "gamecache/wordls/wordl1");

    WORLDGEN::init(world.seed);


    while (!kill_generation_thread) {
        for (int x = LOGIC::player.x / CHUNK_SIZE - screen_width_chunks; float(x / CHUNK_SIZE) <= LOGIC::player.y / CHUNK_SIZE + screen_width_chunks; x++) {
            if (std::find(world.chunks_pos.begin(), world.chunks_pos.end(), x) == world.chunks_pos.end()) {
                // => x not in world.chunks_pos
                // if in_files -> get file and load
                // else ->
                std::cout << "GENERATING " << x << "\n";
                world.chunks.push_back(generate_chunk(x));
                world.chunks_pos.push_back(x);
            }
        }
    }


    log_console("GENERATION", "exited.");
}

void GENERATION::exit() {
    log_console("GENERATION", "requested to exit.");
    kill_generation_thread = true;
}



World::World(const char* _name, const char* _filepath) {
    name = _name;
    filepath = _filepath;
}

Block::Block(int _x, int _y, unsigned long long _blockid) {
    x = _x;
    y = _y;

    blockid = _blockid;

    tx = (_blockid - 1) % spritesheet_width;
    ty = (_blockid - 1) / spritesheet_width;
}

void Block::get_data(std::vector<float>* vertices, std::vector<int>* indices) {
    for (int v : {
            x,     y,       tx,     ty,
            x + 1, y,       tx + 1, ty,
            x + 1, y + 1,   tx + 1, ty + 1,
            x,     y + 1,   tx,     ty + 1
    }) {
        vertices->push_back(v);
    };
    int offset = indices->size() / 6 * 4;
    for (int v : {0, 1, 3, 1, 2, 3}) {
        indices->push_back(v + offset);
    };
}

