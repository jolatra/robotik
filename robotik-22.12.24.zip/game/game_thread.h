#pragma once

#include "../options.h"

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <vector>
#include <thread>

#include "definitions/object.h"



#define AIR		     0
#define DIRT		 1
#define GRASSY_DIRT  2
#define STONE		 3
#define WOOD_NORM    0
#define LEAVES_NORM  0
// spritesheet width in game_thread.cpp

#define CHUNK_SIZE 32

#define screen_width_chunks 1

#define HEIGHT_LIMIT 32

#define spritesheet_width   3
#define spritesheet_height  1

#define blksize_texture     16
#define blksize_screen      60


struct Chunk;
class World;


class Player;


namespace LOGIC {
	void init(int& _LOGIC_STATUS_VAR, int& _GENERATION_STATUS_VAR, GLFWwindow* _window);

	void run();

	void exit(std::thread* thread);

	void get_data(std::vector<float>* vertices, std::vector<int>* indices);
	void get_player_scr_data(std::vector<float>* vertices, std::vector<int>* indices);

	unsigned int get_spritesheet_ID();

	extern Texture main_spritesheet;

	extern Player player;
}


class Player {
public:
	float x, y, w, h;

	Player() {};

	Player(float _x, float _y);

	void get_data(std::vector<float>* vertices, std::vector<int>* indices);

	void moveto(float _x, float _y);
	void moveby(float _x, float _y);
};



// GENERATION

class Block {
public:
	int x;
	int y;

	int tx;
	int ty;

	unsigned long long blockid;

	Block(int _x, int _y, unsigned long long _blockid);

	void get_data(std::vector<float>* vertices, std::vector<int>* indices);
};


struct Chunk { // 32 x inf blocks
public:
	int pos; // 1d

	std::vector<Block> content; // all non-air blocks
	//std::vector<Block> ticked_content;

	Chunk(int x) {
		pos = x;
	}

private:
	int seed;
};



class World {
public:
	std::vector<Chunk> chunks{}; // 1d array, for multiple dimensions use multiple worlds
	std::vector<int>   chunks_pos{};

	const char* name;
	const char* filepath;

	long seed = 0;

	World(const char* name, const char* filepath);

	World() {};
};



namespace GENERATION {
	void init();

	void run();

	void exit();
}

