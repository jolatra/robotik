#include "world_gen.h"

#include "noise/PerlinNoise.h"
#include <iostream>
#include <math.h>

/*
* generation limits: -256, 256
* build limits:		 -256, 256
*/


#define noise1(x)        perlin.noise(x - sin(x), 1 - sin(1), 1 - sin(1))
#define noise2(x, y)     perlin.noise(x - sin(x), y - sin(y), 1 - sin(1))
#define noise3(x, y, z)  perlin.noise(x - sin(x), y - sin(y), z - sin(z))

// block preprocessor directives in game_thread.h
// spritesheet width in game_thread.cpp


long SEED;
PerlinNoise perlin;


Block AIR_BLOCK(0, 0, AIR);


unsigned long long generate_standard(int x, int y);



void WORLDGEN::init(long seed) {
	SEED = seed;
	perlin = PerlinNoise(9087654);
}

unsigned long long generate_block(int x, int y) {
	return generate_standard(x, y);
}



unsigned long long generate_standard(int x, int y) {
	float noise = noise2(x, y);
	float height = noise1((float)x / 20);

	float height_lim = height * HEIGHT_LIMIT;
	if (y > height_lim) {
		return AIR;
	}
	else if (y > height_lim - (int)(2.8f * noise)) {
		return GRASSY_DIRT;
	}
	else if (y > height_lim - (int)(6.0f * noise)) {
		return DIRT;
	}
	else {
		return STONE;
	}
}



Chunk generate_chunk(int x) {
	Chunk cnk(x);

	for (int bx = 0; bx < CHUNK_SIZE; bx++) {
		for (int by = 0; by < HEIGHT_LIMIT; by++) {
			unsigned long long blk = generate_block(x * CHUNK_SIZE + bx, by);
			if (blk != AIR)
				cnk.content.push_back(Block(x * CHUNK_SIZE + bx, by, blk));
		}
	}

	return cnk;
}