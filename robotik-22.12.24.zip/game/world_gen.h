#pragma once

#include "game_thread.h"

namespace WORLDGEN {
	void init(long seed);
};

class Block;
struct Chunk;

unsigned long long generate_block(int x, int y);

Chunk generate_chunk(int x);