#include "options.h"

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/geometric.hpp>

#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <thread>

#include "definitions/shader.h"
#include "definitions/other.h"

#include "game/game_thread.h" // logic and generation thread

#include "debug_thread/debug_thread.h"

#define STB_IMAGE_IMPLEMENTATION
#include "singleheader/stb_image.h"


#define checkErrors() get_Errors(__LINE__, __FILE__)
#define checkKeyPress(window, key) glfwGetKey(window, key) == GLFW_PRESS



unsigned int SCR_WIDTH = 1600;
unsigned int SCR_HEIGHT = 1400;
const float PI = 3.141592653589793f;

Shader BLOCK_SHADER;

std::thread GENERATION_THREAD;
std::thread LOGIC_THREAD;          // if on multiplayer, manages connection
std::thread DEBUG_THREAD;


int LOGIC_THREAD_STATUS = 0;            // 0 -> not started       // 2 -> stopped
int GENERATION_THREAD_STATUS = 0;	    // 1 -> running           // 3 -> error


int BLOCKSIZE_PIX = 40;
float scrx = 0;
float scry = 0;

float fps = 0;



void processInput(GLFWwindow* window) {
    if (checkKeyPress(window, GLFW_KEY_ESCAPE))
        glfwSetWindowShouldClose(window, true);

    float shift = checkKeyPress(window, GLFW_KEY_LEFT_SHIFT) or checkKeyPress(window, GLFW_KEY_RIGHT_SHIFT);

    if (checkKeyPress(window, GLFW_KEY_A)) {
        LOGIC::player.moveby((60 / fps) + shift / 3, 0.0f);
        std::cout << (60 / fps) + shift / 3 << " " << LOGIC::player.x << "\n";
        //SHADER->set1Float("scrx", scrx);
    }
    if (checkKeyPress(window, GLFW_KEY_D)) {
        scrx -= (1 / fps) + shift / 3;
    }
    if (checkKeyPress(window, GLFW_KEY_S)) {
        scry += (1 / fps) + shift / 3;
    }
    if (checkKeyPress(window, GLFW_KEY_W)) {
        scry -= (1 / fps) + shift / 3;
    }
    if (checkKeyPress(window, GLFW_KEY_Q)) {
        scrx = LOGIC::player.x * (float)BLOCKSIZE_PIX / SCR_WIDTH;
        scry = LOGIC::player.y * (float)BLOCKSIZE_PIX / SCR_WIDTH;
        std::cout << scrx << " / " << scry << "\n";
    }
}


void processScroll(GLFWwindow* window, double xoffset, double yoffset) {
    BLOCKSIZE_PIX += yoffset;
}



void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
    SCR_WIDTH = width;
    SCR_HEIGHT = height;
}





int main() {
    // init
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    //glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);

#if MSAA == true
    glfwWindowHint(GLFW_SAMPLES, 4);
#endif

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

#if FULLSCREEN == true
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Hello", glfwGetPrimaryMonitor(), NULL);
#else
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Hello", NULL, NULL);
#endif

    if (window == NULL) {
        std::cout << "ERROR::INIT::WINDOW_CREATE" << std::endl;
        glfwTerminate();
        return -1;
    };

    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetScrollCallback(window, processScroll);
    
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "ERROR::INIT::GLAD" << std::endl;
        return -1;
    };


    // icon (+ init textures)
    stbi_set_flip_vertically_on_load(false);

    GLFWimage icons[1];
    icons[0].pixels = stbi_load("assets/icon.png", &icons[0].width, &icons[0].height, 0, 4); //rgba channels 
    glfwSetWindowIcon(window, 1, icons);
    stbi_image_free(icons[0].pixels);

    stbi_set_flip_vertically_on_load(true);



    // buffers
    unsigned int VBO, VAO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);



    // pos + texpos attr
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);


    
#ifdef MSAA
    glEnable(GL_MULTISAMPLE);
#endif
#ifdef BLEND
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
#endif


    std::vector<float> vertices{};
    std::vector<int>   indices{};


    // shaders
    BLOCK_SHADER  = Shader("shaders/main.vert", "shaders/main.frag");

    BLOCK_SHADER.use();

    BLOCK_SHADER.set2Float("blockSize", (float)BLOCKSIZE_PIX / SCR_WIDTH, (float)BLOCKSIZE_PIX / SCR_HEIGHT);
    BLOCK_SHADER.set2Float("blockTextureSize", 4.0f, 1.0f);


#ifdef MAXIMIZE
    glfwMaximizeWindow(window);
#endif



    // start threads
    DEBUG::init(LOGIC_THREAD_STATUS, GENERATION_THREAD_STATUS);
    DEBUG_THREAD = std::thread(DEBUG::run);

    LOGIC::init(LOGIC_THREAD_STATUS, GENERATION_THREAD_STATUS, window);
    LOGIC_THREAD = std::thread(LOGIC::run);

    // GENERATION init done by LOGIC
    GENERATION_THREAD = std::thread(GENERATION::run);


    float last_time = 0;

    // render loop
    while (!glfwWindowShouldClose(window)) {
        // input
        processInput(window);

        
        // pre-render
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        BLOCK_SHADER.set2Float("blockSize", (float)BLOCKSIZE_PIX / SCR_WIDTH, (float)BLOCKSIZE_PIX / SCR_HEIGHT);
        BLOCK_SHADER.set2Float("scrpos",    (float)BLOCKSIZE_PIX / SCR_WIDTH, (float)BLOCKSIZE_PIX / SCR_HEIGHT);


        // fetch data
        vertices.clear(); indices.clear();
        LOGIC::get_data(&vertices, &indices); // get data of blocks only
        LOGIC::get_player_scr_data(&vertices, &indices);


        // render
        if (!vertices.empty() && !indices.empty()) {
            BLOCK_SHADER.use();
            glBindTexture(GL_TEXTURE_2D, LOGIC::get_spritesheet_ID());

            glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), &vertices[0], GL_DYNAMIC_DRAW);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(int), &indices[0], GL_DYNAMIC_DRAW);

            glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
        }
        

        /*
        spec_vertices.clear(); spec_indices.clear();
        LOGIC::get_player_scr_data(&spec_vertices, &spec_indices);
        if (!spec_vertices.empty() && !spec_indices.empty()) {
            PLAYER_SHADER.use();
            glBindTexture(GL_TEXTURE_2D, LOGIC::get_player_tex_ID());

            glBufferData(GL_ARRAY_BUFFER, spec_vertices.size() * sizeof(float), &spec_vertices[0], GL_DYNAMIC_DRAW);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, spec_indices.size() * sizeof(int), &spec_indices[0], GL_DYNAMIC_DRAW);

            glDrawElements(GL_TRIANGLES, spec_indices.size(), GL_UNSIGNED_INT, 0);
        }*/
        
        glfwSwapBuffers(window);

        std::cout << "rendered " << indices.size() / 4 << " blocks\n";


        glfwPollEvents();

        float this_time = glfwGetTime();
        fps = 1.0f / (this_time - last_time);
        last_time = this_time;

        DEBUG::push_fps(fps);

        //std::this_thread::sleep_for(std::chrono::milliseconds(0));
    }

    log_console("MAIN", "requested to exit.");

    GENERATION::exit();
    LOGIC::exit(&LOGIC_THREAD);

    // quit properly
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    BLOCK_SHADER.kill();

    glfwDestroyWindow(window);

    DEBUG::exit(&DEBUG_THREAD);

    log_console("MAIN", "waiting for GENERATION thread to exit.");
    if (GENERATION_THREAD.joinable()) {
        GENERATION_THREAD.join();
    }

    log_console("MAIN", "exited; program stopped.");

    return 0;
}



