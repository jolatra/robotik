#pragma once

#define ENABLE_DEBUG // delete this to remove debug features

//#define MAXIMIZE
//#define FULLSCREEN
#define MSAA true
#define BLEND true